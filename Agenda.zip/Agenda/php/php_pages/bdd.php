<?php
  // Données pour se connecter
  $serveur = "localhost";
  $login = "root";
  $mdp = "";
  $bdd_name = 'agenda';
?>